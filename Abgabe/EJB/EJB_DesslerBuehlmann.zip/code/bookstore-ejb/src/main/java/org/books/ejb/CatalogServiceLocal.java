package org.books.ejb;

import javax.ejb.Local;

@Local
public interface CatalogServiceLocal extends CatalogService {

}
