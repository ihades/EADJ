package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class BookAlreadyExistsException extends Exception {

}
