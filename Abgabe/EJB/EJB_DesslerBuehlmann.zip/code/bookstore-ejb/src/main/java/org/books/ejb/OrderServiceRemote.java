package org.books.ejb;

import javax.ejb.Remote;

/**
 *
 * @author cb
 */
@Remote
public interface OrderServiceRemote extends OrderService {

}
