package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class InvalidPasswordException extends Exception {

}
