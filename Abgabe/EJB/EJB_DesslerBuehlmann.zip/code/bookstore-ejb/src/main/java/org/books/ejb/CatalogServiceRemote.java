package org.books.ejb;

import javax.ejb.Remote;

@Remote
public interface CatalogServiceRemote extends CatalogService {

}
