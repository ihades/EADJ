package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class CustomerAlreadyExistsException extends Exception {

}
