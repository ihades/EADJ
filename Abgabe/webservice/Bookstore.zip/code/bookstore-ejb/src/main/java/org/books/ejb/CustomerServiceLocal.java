package org.books.ejb;

import javax.ejb.Local;

/**
 *
 * @author cb
 */
@Local
public interface CustomerServiceLocal extends CustomerService {

}
