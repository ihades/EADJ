package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class BookNotFoundException extends Exception {

}
