package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class OrderNotFoundException extends Exception {

}
