package org.books.ejb;

import javax.ejb.Remote;

/**
 *
 * @author cb
 */
@Remote
public interface CustomerServiceRemote extends CustomerService {

}
