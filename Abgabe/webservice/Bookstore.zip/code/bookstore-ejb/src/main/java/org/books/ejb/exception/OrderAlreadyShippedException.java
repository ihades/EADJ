package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class OrderAlreadyShippedException extends Exception {

}
