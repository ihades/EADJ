package org.books.ejb;

import javax.ejb.Local;

/**
 *
 * @author cb
 */
@Local
public interface OrderServiceLocal extends OrderService {

}
