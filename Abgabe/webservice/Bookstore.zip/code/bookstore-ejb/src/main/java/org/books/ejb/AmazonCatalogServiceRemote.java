package org.books.ejb;

import javax.ejb.Remote;

@Remote
public interface AmazonCatalogServiceRemote extends AmazonCatalogService {

}
