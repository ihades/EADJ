package org.books.ejb.exception;

/**
 *
 * @author cb
 */
public class CustomerNotFoundException extends Exception {

}
