package org.books.web.presentation.util;

/**
 * The class MessageFactory is used to create faces messages.
 */
public class LoginException extends Exception {

}
